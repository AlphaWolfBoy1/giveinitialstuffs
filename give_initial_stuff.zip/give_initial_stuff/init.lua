--🧊 ⛸ 🍧 🏒 🍨 ❄ 🧊 ⛸ 🍧 🏒 🍨 ❄ 🧊 
local give_if_not_gotten_already = function(inv, list, item)
	if not inv:contains_item(list, item) then
		inv:add_item(list, item)
	end
end

local give_initial_stuff = function(player)
	local inv = player:get_inventory()
	give_if_not_gotten_already(inv, "main", "default:pick_steel")
	give_if_not_gotten_already(inv, "main", "default:axe_steel")
	give_if_not_gotten_already(inv, "main", "protector:protect 4")
	give_if_not_gotten_already(inv, "main", "default:sword_wood")
	give_if_not_gotten_already(inv, "main", "default:torch 99")
	minetest.log("action", "[give_initial_stuff] Giving initial stuff to "..player:get_player_name())
end

minetest.register_on_newplayer(function(player)
	if minetest.settings:get_bool("give_initial_stuff", true) then
		give_initial_stuff(player)
	end
end)

minetest.register_chatcommand("stuff", {
	params = "",
	privs = { give = true },
	description = "Give yourself initial items",
	func = function(name, param)
		local player = minetest.get_player_by_name(name)
		if not player or not player:is_player() then
			return false, "No player."
		end
		give_initial_stuff(player)
		return true
	end,
})

minetest.register_on_joinplayer(function(player)
	player:set_properties({physical = false})
end)

minetest.register_on_joinplayer(function(player)
	local cb = function(player)
		if not player or not player:is_player() then
			return
		end
		minetest.chat_send_player(player:get_player_name(), minetest.colorize("#fcba03", "need to go mining? go to the spawn and go to the travelnet center, you will find public mines in the last travelnet!\n"))
	end
	minetest.after(120, cb, player)
end)
